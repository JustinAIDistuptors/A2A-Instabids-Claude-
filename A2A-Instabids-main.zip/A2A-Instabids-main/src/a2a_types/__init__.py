# This file makes 'a2a_types' a Python sub-package.

# Optionally expose core types directly from the package
# from .core import Agent, Task, Message, Artifact, AgentId, TaskId, MessageId, ArtifactId
