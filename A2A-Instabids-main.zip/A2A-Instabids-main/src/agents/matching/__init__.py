# This file makes 'matching' a Python sub-package.

# Expose the main agent class
from .agent import MatchingAgent
