# This file makes 'homeowner' a Python sub-package.

# Expose the main agent class
from .agent import HomeownerAgent
