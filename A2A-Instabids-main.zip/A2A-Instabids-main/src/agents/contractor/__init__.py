# This file makes 'contractor' a Python sub-package.

# Expose the main agent class
from .agent import ContractorAgent
