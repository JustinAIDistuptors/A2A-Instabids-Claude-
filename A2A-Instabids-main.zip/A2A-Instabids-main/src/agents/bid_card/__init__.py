# This file makes 'bid_card' a Python sub-package.

# Expose the main agent class
from .agent import BidCardAgent
